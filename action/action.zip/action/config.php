<?php

	$plugin_config = array();
	$plugin_config["admin"] = 0;
	$plugin_config["name"] = "action";
	$plugin_config["title"] = "Блоки";
	$plugin_config["extend"] = 1;
	$plugin_config["cache"] = 1;
	
?>