<?php
if(!defined("BENGINE")) {die ("Hacking!");}
?>